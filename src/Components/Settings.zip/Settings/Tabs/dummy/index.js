import React, { Component } from "react";
import './index.css'

export default class  extends Component {

  render() {

    return (
      <div className="" >
      
      </div>
    );
  }
}
